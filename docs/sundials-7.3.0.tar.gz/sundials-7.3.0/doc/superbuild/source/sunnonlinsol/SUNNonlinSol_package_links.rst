..
   ----------------------------------------------------------------
   SUNDIALS Copyright Start
   Copyright (c) 2002-2025, Lawrence Livermore National Security
   and Southern Methodist University.
   All rights reserved.

   See the top-level LICENSE and NOTICE files for details.

   SPDX-License-Identifier: BSD-3-Clause
   SUNDIALS Copyright End
   ----------------------------------------------------------------

.. include:: ../../../arkode/guide/source/sunnonlinsol/ARKODE_interface.rst
.. include:: ../../../cvode/guide/source/sunnonlinsol/CVODE_interface.rst
.. include:: ../../../cvodes/guide/source/sunnonlinsol/CVODES_interface.rst
.. include:: ../../../ida/guide/source/sunnonlinsol/IDA_interface.rst
.. include:: ../../../idas/guide/source/sunnonlinsol/IDAS_interface.rst