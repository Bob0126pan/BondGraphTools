..
   ----------------------------------------------------------------
   SUNDIALS Copyright Start
   Copyright (c) 2002-2025, Lawrence Livermore National Security
   and Southern Methodist University.
   All rights reserved.

   See the top-level LICENSE and NOTICE files for details.

   SPDX-License-Identifier: BSD-3-Clause
   SUNDIALS Copyright End
   ----------------------------------------------------------------

.. include:: ../../../arkode/guide/source/sunlinsol/ARKODE_interface.rst
.. include:: ../../../cvode/guide/source/sunlinsol/CVODE_interface.rst
.. include:: ../../../cvodes/guide/source/sunlinsol/CVODES_interface.rst
.. include:: ../../../ida/guide/source/sunlinsol/IDA_interface.rst
.. include:: ../../../idas/guide/source/sunlinsol/IDAS_interface.rst
.. include:: ../../../kinsol/guide/source/sunlinsol/KINSOL_interface.rst